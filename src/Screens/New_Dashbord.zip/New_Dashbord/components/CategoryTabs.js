import React from 'react';
import {
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const { width: screenWidth } = Dimensions.get('window');

const CategoryTabs = ({ categories, activeTab, setActiveTab, loading = false }) => {

  const CategoryButton = ({ category, isActive }) => {
    const iconBackgroundColor = isActive ? category.color || '#4A148C' : '#f8f8f8';

    return (
      <TouchableOpacity
        style={[
          styles.categoryTouchable,
          isActive && styles.activeCategoryButton,
        ]}
        onPress={() => setActiveTab(category.name)}
        activeOpacity={0.7}
        disabled={loading}
      >
        <View style={styles.categoryIconContainer}>
          {isActive ? (
            <LinearGradient
              colors={[category.color || '#4A148C', `${category.color || '#4A148C'}88`]}
              style={styles.categoryIcon}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <Text style={[styles.categoryEmoji, isActive && styles.activeCategoryEmoji]}>
                {category.icon}
              </Text>
            </LinearGradient>
          ) : (
            <View style={[styles.categoryIcon, { backgroundColor: iconBackgroundColor }]}>
              <Text style={styles.categoryEmoji}>{category.icon}</Text>
            </View>
          )}
          {isActive && (
            <View style={[styles.activeDot, { backgroundColor: category.color || '#4A148C' }]} />
          )}
        </View>

        <Text
          style={[
            styles.categoryText,
            isActive && [styles.activeCategoryText, { color: category.color || '#4A148C' }],
          ]}
          numberOfLines={1}
          adjustsFontSizeToFit
        >
          {category.name}
        </Text>

        {isActive && (
          <View style={[styles.activeIndicator, { backgroundColor: category.color || '#4A148C' }]} />
        )}
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.scrollView}
        contentContainerStyle={styles.scrollContent}
        bounces={false}
        decelerationRate="fast"
        scrollEventThrottle={16}
      >
        {categories.map((category) => (
          <CategoryButton
            key={category.name}
            category={category}
            isActive={activeTab === category.name}
          />
        ))}
      </ScrollView>

      <View style={styles.bottomDivider} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    paddingBottom: 8,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
  },
  scrollView: {
    paddingHorizontal: 8,
  },
  scrollContent: {
    paddingHorizontal: 8,
    alignItems: 'center',
  },
  categoryTouchable: {
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 16,
    minWidth: 70,
    position: 'relative',
    marginRight: 24,
  },
  activeCategoryButton: {
    backgroundColor: '#f8f9fa',
  },
  categoryIconContainer: {
    position: 'relative',
    marginBottom: 8,
  },
  categoryIcon: {
    width: 52,
    height: 52,
    borderRadius: 26,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  categoryEmoji: {
    fontSize: 26,
  },
  activeCategoryEmoji: {
    fontSize: 28,
    textShadowColor: '#00000020',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },
  activeDot: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: '#fff',
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 2,
  },
  categoryText: {
    fontSize: 13,
    color: '#666',
    fontWeight: '500',
    textAlign: 'center',
    marginBottom: 4,
    lineHeight: 16,
  },
  activeCategoryText: {
    fontWeight: '700',
    fontSize: 14,
    textShadowColor: '#00000010',
    textShadowOffset: { width: 0, height: 0.5 },
    textShadowRadius: 1,
  },
  activeIndicator: {
    position: 'absolute',
    bottom: 0,
    left: '20%',
    right: '20%',
    height: 3,
    borderRadius: 2,
    elevation: 1,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
  },
  bottomDivider: {
    height: 1,
    backgroundColor: '#f0f0f0',
    marginHorizontal: 16,
  },
});

export default CategoryTabs;
