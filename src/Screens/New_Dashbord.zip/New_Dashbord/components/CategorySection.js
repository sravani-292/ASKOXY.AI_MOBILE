// components/CategorySection.js
import React, { memo, useCallback, useMemo } from 'react';
import { View, Text, Image, TouchableOpacity, ScrollView, StyleSheet } from 'react-native';
import ProductCard from './ProductCard';

const CategorySection = memo(({
  categoryTypeData,
  addToCart,
  removeFromCart,
  getItemInCart,
  calculateDiscount,
  customerId
}) => {
  // Memoize the renderItem function to prevent unnecessary re-renders
  const renderProductCard = useCallback((item) => {
    const cartItem = getItemInCart(item.itemId);
    const discount = calculateDiscount(item.itemMrp, item.itemPrice);

    return (
      <ProductCard
        key={item.itemId}
        item={item}
        onAddToCart={addToCart}
        cartItem={cartItem} // cartItem should be a single object or undefined
        onDecrement={removeFromCart}
        discount={discount}
        customerId={customerId}
      />
    );
  }, [addToCart, removeFromCart, getItemInCart, calculateDiscount, customerId]);

  // Memoize the category rendering
  const renderCategory = useCallback((category) => (
    <View key={category.categoryName} style={styles.section}>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Image style={styles.logo} source={{ uri: category.categoryLogo }} />
          <Text style={styles.title}>{category.categoryName}</Text>
        </View>
        <TouchableOpacity>
          <Text style={styles.seeAll}>See All</Text>
        </TouchableOpacity>
      </View>

      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false} 
        style={styles.scroll}
        nestedScrollEnabled={true}
      >
        {category.itemsResponseDtoList.map(renderProductCard)}
      </ScrollView>
    </View>
  ), [renderProductCard]);

  return (
    <View key={categoryTypeData.categoryType}>
      {categoryTypeData.categories.map(renderCategory)}
    </View>
  );
});

// Add display name for debugging
CategorySection.displayName = 'CategorySection';

const styles = StyleSheet.create({
  section: { 
    marginBottom: 20 
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    marginBottom: 12,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  logo: {
    height: 35,
    width: 35,
    borderRadius: 100,
    marginRight: 15,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  seeAll: {
    fontSize: 14,
    color: '#FF6B35',
  },
  scroll: {
    paddingHorizontal: 16,
  },
});

export default CategorySection;