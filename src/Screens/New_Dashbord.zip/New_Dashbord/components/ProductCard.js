// components/ProductCard.js
import React, { useState, useCallback, useMemo, memo, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import formatUnit from '../../../../until/unitsChange';
import BASE_URL from '../../../../Config';

const ProductCard = memo(({ item, onAddToCart, cartItem, onDecrement, discount, customerId }) => {
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Reset loading state when cartItem changes
    if (cartItem) {
      setLoading(false);
    }
    
  }, [cartItem]);

  const handleIncrement = useCallback(async (item) => {
    if (loading) return; // Prevent multiple rapid taps
    
    try {
      setLoading(true);
      console.log('Incrementing cart for item:', item.itemId);
      console.log('cart Items:', cartItem);
      await onAddToCart(item);
    } catch (error) {
      console.error('Error incrementing cart:', error);
    } finally {
      setLoading(false);
    }
  }, [onAddToCart, loading]);

  const handleDecrement = useCallback(async () => {
    if (loading) return; // Prevent multiple rapid taps
    
    try {
      setLoading(true);
      await onDecrement(cartItem.cartId, customerId);
    } catch (error) {
      console.error('Error decrementing cart:', error);
    } finally {
      setLoading(false);
    }
  }, [onDecrement, cartItem?.cartId, customerId, loading]);

  // Memoize calculated values to avoid recalculating on every render
  const savings = useMemo(() => {
    if (item.itemMrp > item.itemPrice) {
      return item.itemMrp - item.itemPrice;
    }
    return 0;
  }, [item.itemMrp, item.itemPrice]);

  const formattedWeight = useMemo(() => {
    return `${item.weight}${formatUnit(item.weight, item.units)}`;
  }, [item.weight, item.units]);

  const hasDiscount = useMemo(() => discount > 0, [discount]);
  const hasSavings = useMemo(() => savings > 0, [savings]);
  const hasRating = useMemo(() => !!item.rating, [item.rating]);
  const hasBrand = useMemo(() => !!item.brand, [item.brand]);
  const hasCartItem = useMemo(() => !!cartItem, [cartItem]);

  // Memoize styles that depend on loading state
  const controlButtonStyle = useMemo(() => [
    styles.controlButton,
    loading && styles.disabledButton
  ], [loading]);

  const addButtonStyle = useMemo(() => [
    styles.addButton,
    loading && styles.disabledButton
  ], [loading]);

  return (
    <View style={styles.cardContainer}>
      <LinearGradient
        colors={['#ffffff', '#f3f0ff']}
        style={styles.card}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      >
        {/* Discount Badge */}
        {hasDiscount && (
          <LinearGradient
            colors={['#8B5CF6', '#A78BFA']}
            style={styles.discountBadge}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <Text style={styles.discountText}>{discount}% OFF</Text>
          </LinearGradient>
        )}

        {/* Product Image Container */}
        <LinearGradient
          colors={['#faf5ff', '#f3e8ff']}
          style={styles.imageContainer}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <Image 
            source={{ uri: item.itemImage }} 
            style={styles.image} 
            resizeMode="contain"
            // Add these props for better performance
            fadeDuration={0}
            progressiveRenderingEnabled={true}
          />
          
          {/* Wishlist/Favorite Button */}
          <TouchableOpacity 
            style={styles.favoriteButton}
            activeOpacity={0.7}
          >
            <LinearGradient
              colors={['#ffffff', '#faf5ff']}
              style={styles.favoriteGradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            >
              <Ionicons name="heart-outline" size={16} color="#8B5CF6" />
            </LinearGradient>
          </TouchableOpacity>
        </LinearGradient>

        <View style={styles.info}>
          {/* Weight and Brand */}
          <View style={styles.weightContainer}>
            <Text style={styles.weight}>
              {formattedWeight}
            </Text>
            {hasBrand && (
              <LinearGradient
                colors={['#F3E8FF', '#E9D5FF']}
                style={styles.brandBadge}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <Text style={styles.brandText}>BRAND</Text>
              </LinearGradient>
            )}
          </View>

          {/* Product Name */}
          <Text style={styles.name} numberOfLines={2}>{item.itemName}</Text>

          {/* Rating (if available) */}
          {hasRating && (
            <View style={styles.ratingContainer}>
              <Ionicons name="star" size={12} color="#FFD700" />
              <Text style={styles.ratingText}>{item.rating}</Text>
              <Text style={styles.ratingCount}>({item.ratingCount || 0})</Text>
            </View>
          )}

          {/* Price Section */}
          <View style={styles.priceContainer}>
            <View style={styles.priceRow}>
              <Text style={styles.price}>₹{item.itemPrice}</Text>
              {item.itemMrp > item.itemPrice && (
                <Text style={styles.strike}>₹{item.itemMrp}</Text>
              )}
            </View>
            {hasSavings && (
              <Text style={styles.savings}>You save ₹{savings}</Text>
            )}
          </View>

          {/* Controls */}
          <View style={styles.controls}>
            {hasCartItem ? (
              <LinearGradient
                colors={['#8B5CF6', '#7C3AED']}
                style={styles.quantityControls}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <TouchableOpacity
                  style={controlButtonStyle}
                  onPress={handleDecrement}
                  disabled={loading}
                  activeOpacity={0.7}
                >
                  <LinearGradient
                    colors={['rgba(255, 255, 255, 0.3)', 'rgba(255, 255, 255, 0.1)']}
                    style={styles.controlButtonGradient}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                  >
                    <Ionicons name="remove" size={16} color="#fff" />
                  </LinearGradient>
                </TouchableOpacity>
                
                <View style={styles.quantityContainer}>
                  <Text style={styles.cartQtyText}>{cartItem.cartQuantity}</Text>
                </View>
                
                <TouchableOpacity
                  style={controlButtonStyle}
                  onPress={() => handleIncrement(item)}
                  disabled={loading}
                  activeOpacity={0.7}
                >
                  <LinearGradient
                    colors={['rgba(255, 255, 255, 0.3)', 'rgba(255, 255, 255, 0.1)']}
                    style={styles.controlButtonGradient}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                  >
                    <Ionicons name="add" size={16} color="#fff" />
                  </LinearGradient>
                </TouchableOpacity>
              </LinearGradient>
            ) : (
              <TouchableOpacity 
                style={addButtonStyle} 
                onPress={() => handleIncrement(item)} 
                disabled={loading}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#f3e8ff', '#e9d5ff']}
                  style={styles.addButtonGradient}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                >
                  <Ionicons name="add" size={18} color="#8B5CF6" />
                  <Text style={styles.addButtonText}>
                    {loading ? 'ADDING...' : 'ADD'}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </LinearGradient>
    </View>
  );
});

// Add display name for debugging
ProductCard.displayName = 'ProductCard';

const styles = StyleSheet.create({
  cardContainer: {
    width: 170,
    marginRight: 14,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.15,
    shadowRadius: 10,
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 15,
    backgroundColor: '#fff', // Add explicit background color
  },
  
  card: {
    flex: 1,
    borderRadius: 16,
    padding: 0,
    overflow: 'hidden',
  },
  
  discountBadge: {
    position: 'absolute',
    top: 8,
    left: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    zIndex: 10,
  },
  
  discountText: {
    fontSize: 10,
    color: '#fff',
    fontWeight: '700',
  },
  
  imageContainer: {
    position: 'relative',
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  
  image: {
    width: '100%',
    height: 90,
    borderRadius: 8,
  },
  
  favoriteButton: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 28,
    height: 28,
    borderRadius: 14,
    overflow: 'hidden',
  },
  
  favoriteGradient: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  info: {
    padding: 12,
    flex: 1,
  },
  
  weightContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  
  weight: {
    fontSize: 12,
    color: '#666',
    fontWeight: '500',
  },
  
  brandBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
  },
  
  brandText: {
    fontSize: 8,
    color: '#7C3AED',
    fontWeight: '600',
  },
  
  name: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1A1A1A',
    lineHeight: 18,
    marginBottom: 6,
  },
  
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  
  ratingText: {
    fontSize: 12,
    color: '#333',
    fontWeight: '500',
    marginLeft: 4,
  },
  
  ratingCount: {
    fontSize: 11,
    color: '#999',
    marginLeft: 4,
  },
  
  priceContainer: {
    marginBottom: 12,
  },
  
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 2,
  },
  
  price: {
    fontSize: 16,
    fontWeight: '700',
    color: '#1A1A1A',
    marginRight: 8,
  },
  
  strike: {
    fontSize: 13,
    color: '#999',
    textDecorationLine: 'line-through',
    fontWeight: '500',
  },
  
  savings: {
    fontSize: 11,
    color: '#8B5CF6',
    fontWeight: '600',
  },
  
  controls: {
    marginTop: 'auto',
  },
  
  quantityControls: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    paddingVertical: 8,
    paddingHorizontal: 4,
    justifyContent: 'space-between',
  },
  
  controlButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    overflow: 'hidden',
  },
  
  controlButtonGradient: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  
  quantityContainer: {
    minWidth: 40,
    alignItems: 'center',
  },
  
  cartQtyText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  
  addButton: {
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: '#8B5CF6',
  },
  
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  
  addButtonText: {
    color: '#8B5CF6',
    fontSize: 13,
    fontWeight: '700',
    marginLeft: 4,
  },
  
  disabledButton: {
    opacity: 0.6,
  },
});

export default ProductCard;