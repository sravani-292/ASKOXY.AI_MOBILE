import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StatusBar,
  SafeAreaView,
  ActivityIndicator,
  StyleSheet,
  TextInput,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  Keyboard,
} from 'react-native';
import axios from 'axios';

import Header from "../components/Header";
import CategoryTabs from "../components/CategoryTabs";
import CategorySection from "../components/CategorySection";
import CartButton from "../components/CartButton";
import PromoCarousel from "../components/PromoBanner";
import BASE_URL from "../../../../Config";
import useServiceScreenData from "../../ServiceScreen/hooks/useServiceScreenData";
import LoginModal from "../../../Components/LoginModal";
import { getActivePriorityRules } from "../../ServiceScreen/constants/ActivePriorityRules";
import { handleCustomerCartData, handleUserAddorIncrementCart } from '../../../ApiService';


const NewDashBoard = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("All");
  const [cartItems, setCartItems] = useState([]);
  const [apiData, setApiData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tabLoading, setTabLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const debounceTimeoutRef = useRef(null);
  const flatListRef = useRef(null);

  const { userData, loginModal, setLoginModal, visibilityMap } = useServiceScreenData();

  const getIconForCategory = (categoryType) => {
    switch ((categoryType || '').toUpperCase()) {
      case "RICE": return "🍚";
      case "GROCERY": return "🥬";
      case "GOLD": return "💍";
      case "FESTIVAL": return "🎁";
      default: return "🛍️";
    }
  };

  useEffect(() => {
    if (debounceTimeoutRef.current) {
      clearTimeout(debounceTimeoutRef.current);
    }

    debounceTimeoutRef.current = setTimeout(() => {
      setDebouncedSearchQuery(searchQuery);
    }, 300);

    return () => {
      if (debounceTimeoutRef.current) {
        clearTimeout(debounceTimeoutRef.current);
      }
    };
  }, [searchQuery]);

  const fetchData = async (showRefreshLoader = false) => {
    try {
      if (showRefreshLoader) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setError(null);

      const priorityRules = await getActivePriorityRules("RICE");
      const response = await axios.get(BASE_URL + "product-service/showGroupItemsForCustomrs");
      const allCategories = response.data || [];

      const priorityOrder = ["RICE", "Grocery", "GOLD"];
      const sortedCategoryTypes = [
        ...priorityOrder,
        ...allCategories
          .map((cat) => cat.categoryType)
          .filter((type) => type && !priorityOrder.includes(type))
          .sort((a, b) => a.localeCompare(b)),
      ];

      const filteredCategories = sortedCategoryTypes
        .map((type) => allCategories.find(
          (cat) => cat.categoryType?.trim().toLowerCase() === type.toLowerCase()
        ))
        .filter(Boolean);

      const riceCategoryIndex = filteredCategories.findIndex(
        (cat) => cat.categoryType === "RICE"
      );

      if (riceCategoryIndex !== -1) {
        const riceCategory = filteredCategories[riceCategoryIndex];

        riceCategory.categories = (riceCategory.categories || []).filter(
          (cat) => cat.categoryName?.trim().toLowerCase() !== "rice container"
        );

        riceCategory.categories.sort((a, b) => {
          const getPriority = (name) => {
            const rule = priorityRules.find(
              (r) => r.match_scope === "category" && name?.toLowerCase().includes(r.match_text.toLowerCase())
            );
            return rule ? rule.priority_order : 999;
          };
          return getPriority(a.categoryName) - getPriority(b.categoryName);
        });

        riceCategory.categories.forEach((sub) => {
          if (Array.isArray(sub.itemsResponseDtoList)) {
            sub.itemsResponseDtoList.sort((a, b) => {
              const getPriority = (name) => {
                const rule = priorityRules.find(
                  (r) => r.match_scope === "item" && name?.toLowerCase().includes(r.match_text.toLowerCase())
                );
                return rule ? rule.priority_order : 999;
              };
              return getPriority(a.itemName) - getPriority(b.itemName);
            });
          }
        });

        filteredCategories[riceCategoryIndex] = riceCategory;
      }

      setApiData(filteredCategories);
      filterData(filteredCategories, debouncedSearchQuery, activeTab);

    } catch (error) {
      console.error("Error fetching categories:", error);
      setError(error.message || "Failed to fetch data");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const filterData = (allData, search, tab) => {
    const filtered = allData
      .filter(
        (item) =>
          tab === "All" ||
          item.categoryType?.toLowerCase() === tab.toLowerCase()
      )
      .map((item) => ({
        ...item,
        categories: (item.categories || [])
          .map((cat) => ({
            ...cat,
            itemsResponseDtoList: (cat.itemsResponseDtoList || []).filter((prod) =>
              prod.itemName.toLowerCase().includes(search.toLowerCase())
            ),
          }))
          .filter((cat) => cat.itemsResponseDtoList.length > 0),
      }))
      .filter((item) => item.categories.length > 0);

    setFilteredData(filtered);
  };

  useEffect(() => {
    if (apiData.length === 0) {
      fetchData();
    }
    if(userData) {
    fetchCartItems();
    }
  }, []);

  useEffect(() => {
    if (apiData.length > 0) {
      filterData(apiData, debouncedSearchQuery, activeTab);
    }
  }, [debouncedSearchQuery, activeTab]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setTabLoading(true);
    filterData(apiData, debouncedSearchQuery, tab);
    if (flatListRef.current) {
      flatListRef.current.scrollToOffset({ offset: 0, animated: true });
    }
    setTimeout(() => {
      setTabLoading(false);
    }, 200);
  };

  const addToCart = (item) => {
    try {
      setLoading(true);
      console.log('Adding item to cart:', item.itemId);
      const data = {
        customerId: userData?.userId,
        itemId: item.itemId,
      };
      const response = handleUserAddorIncrementCart(data, "ADD");
      fetchCartItems()
    } catch (error) { 
      console.error('Error adding item to cart:', error);
    } finally {
      setLoading(false);
    }
    
  };

   const fetchCartItems = async () => {
      try {
        const response = await handleCustomerCartData(userData?.userId);
  
        const cartData = response?.data?.customerCartResponseList;
        const totalCartCount = cartData.reduce(
          (total, item) => total + item.cartQuantity,
          0
        );
  
        if (!cartData || !Array.isArray(cartData) || cartData.length === 0) {
          // setCartData([]);
          setCartItems([]);
          // setIsLimitedStock({});
          // setCartCount(0);
          return;
        }
  
        const cartItemsMap = cartData.reduce((acc, item) => {
          if (
            !item.itemId ||
            item.cartQuantity === undefined ||
            item.quantity === undefined ||
            item.status != "ADD"
          ) {
            return acc;
          }
          acc[item.itemId] = item.cartQuantity;
          return acc;
        }, {});
  
        const limitedStockMap = cartData.reduce((acc, item) => {
          if (item.quantity === 0) {
            acc[item.itemId] = "outOfStock";
          } else if (item.quantity <= 5) {
            acc[item.itemId] = "lowStock";
          }
          return acc;
        }, {});
        //  console.log("Cart Items Map:", cartData);
         
        setCartItems(cartData);
        // setCartItems(cartItemsMap);
        // setIsLimitedStock(limitedStockMap);
        // setCartCount(totalCartCount);
      } catch (error) {
        console.error("Error fetching cart items:", error);
      }
    };

  const removeFromCart = (itemId) => {
       console.log('Removing item from cart:', itemId);
       
    fetchCartItems()
  };

  // const getItemInCart = (itemId) => {
  //   return cartItems.find((i) => i.itemId === itemId);
  // };
  const getItemInCart = (itemId) => {
  return cartItems.find(cart => cart.itemId === itemId); // Returns single item or undefined
};

  const calculateDiscount = (mrp, price) => {
    return Math.round(((mrp - price) / mrp) * 100);
  };

  const getTotalCartItems = () => {
    return cartItems.reduce((sum, i) => sum + i.cartQuantity, 0);
  };

  const getTotalCartValue = () => {
    return cartItems.reduce((sum, i) => sum + i.itemPrice * i.cartQuantity, 0);
  };

  const handleSearchChange = (text) => {
    setSearchQuery(text);
  };

  const clearSearch = () => {
    setSearchQuery("");
    Keyboard.dismiss();
  };

  const onRefresh = () => {
    fetchData(true);
  };

  const renderCategoryItem = ({ item }) => (
    <CategorySection
      categoryTypeData={item}
      addToCart={addToCart}
      removeFromCart={removeFromCart}
      getItemInCart={getItemInCart}
      calculateDiscount={calculateDiscount}
      customerId={userData?.userId}
    />
  );

  const categories = [
    { name: "All", icon: "🛒" },
    ...apiData.map((cat) => ({
      name: cat.categoryType,
      icon: getIconForCategory(cat.categoryType),
    })),
  ];

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#4A148C" />
          <Text style={styles.loadingText}>Loading products...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (error) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.errorContainer}>
          <Text style={styles.errorText}>⚠️ {error}</Text>
          <TouchableOpacity style={styles.retryButton} onPress={() => fetchData()}>
            <Text style={styles.retryButtonText}>Retry</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#fff" />
      <Header />
      <View style={styles.searchBarContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search for products..."
          value={searchQuery}
          onChangeText={handleSearchChange}
          returnKeyType="search"
          onSubmitEditing={() => Keyboard.dismiss()}
        />
        {searchQuery.length > 0 && (
          <TouchableOpacity onPress={clearSearch} style={styles.clearButton}>
            <Text style={styles.clearButtonText}>✕</Text>
          </TouchableOpacity>
        )}
      </View>
      <CategoryTabs
        categories={categories}
        activeTab={activeTab}
        setActiveTab={handleTabChange}
      />
      {/* <PromoCarousel /> */}
      {tabLoading ? (
        <View style={styles.loadingTabContainer}>
          <ActivityIndicator size="small" color="#4A148C" />
          <Text style={styles.loadingText}>Loading products...</Text>
        </View>
      ) : filteredData.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>
            {searchQuery 
              ? `No products found for "${searchQuery}"` 
              : "No products available"}
          </Text>
          {searchQuery && (
            <TouchableOpacity onPress={clearSearch} style={styles.clearSearchButton}>
              <Text style={styles.clearSearchButtonText}>Clear Search</Text>
            </TouchableOpacity>
          )}
        </View>
      ) : (
        <FlatList
          ListHeaderComponent={<PromoCarousel />}
          ref={flatListRef}
          data={filteredData}
          keyExtractor={(item) => item.categoryType}
          renderItem={renderCategoryItem}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={['#4A148C']}
              tintColor="#4A148C"
            />
          }
          showsVerticalScrollIndicator={false}
          ListFooterComponent={<View style={{ height: 80 }} />}
          initialNumToRender={10}
          maxToRenderPerBatch={10}
          windowSize={10}
          removeClippedSubviews={true}
          getItemLayout={(data, index) => ({ length: 220, offset: 220 * index, index })}
          extraData={cartItems}
        />
     
      )}
      {cartItems.length > 0 && (
        <CartButton
          totalItems={getTotalCartItems()}
          totalValue={getTotalCartValue()}
          onPress={() => console.log("Go to cart")}
        />
      )}
      {!userData && (
        <LoginModal 
          visible={loginModal} 
          onClose={() => setLoginModal(false)} 
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", marginTop: 50 },
  loadingContainer: { flex: 1, justifyContent: "center", alignItems: "center" },
  loadingTabContainer: { paddingVertical: 20, alignItems: "center" },
  loadingText: { marginTop: 8, fontSize: 16, color: "#666", textAlign: "center", fontWeight: "bold" },
  errorContainer: { flex: 1, justifyContent: "center", alignItems: "center", padding: 20 },
  errorText: { fontSize: 16, color: "#380675ff", textAlign: "center", marginBottom: 20 },
  retryButton: { backgroundColor: "#4A148C", paddingHorizontal: 20, paddingVertical: 10, borderRadius: 8 },
  retryButtonText: { color: "#fff", fontSize: 16, fontWeight: "bold" },
  emptyContainer: { flex: 1, justifyContent: "center", alignItems: "center", padding: 20 },
  emptyText: { fontSize: 16, color: "#666", textAlign: "center", marginBottom: 20 },
  clearSearchButton: { backgroundColor: "#4A148C", paddingHorizontal: 20, paddingVertical: 10, borderRadius: 8 },
  clearSearchButtonText: { color: "#fff", fontSize: 14, fontWeight: "bold" },
  bottomSpacing: { height: 100 },
  searchBarContainer: { marginHorizontal: 16, marginVertical: 8, borderWidth: 1, borderColor: "#ccc", borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8, flexDirection: "row", alignItems: "center" },
  searchInput: { flex: 1, fontSize: 16, color: "#333" },
  clearButton: { padding: 5, marginLeft: 8 },
  clearButtonText: { fontSize: 18, color: "#666" },
});

export default NewDashBoard;
